
public class Bai1_TimSo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int tong = 1, a = 0;

		do {
			tong += a;
			a++;
			//System.out.println(tong);

		} while (tong < 5000);
		 System.out.println("n bé nhât = " + a);

	}

}

package com.cybersoft.quanlynhansu;

public interface IXuatNhap {
	void nhapThongTin();
	void xuatThongTin();
}

package com.cybersoft.abstraction;

import com.cybersoft.quanlynhansu.IXuatNhap;

public class VatTu implements IXuatNhap {

	@Override
	public void nhapThongTin() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void xuatThongTin() {
		// TODO Auto-generated method stub
		
	}

}
